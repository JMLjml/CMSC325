CMSC325 Project 2
John M. Lasheski
February 21, 2015

1. Import .ZIP file and build like any other jmonkey project.

2. The simluation will run until the user exits the program or there have been 100
   collisions detected between the spheres. The collision data is stored in a file
   called collisions.txt.
